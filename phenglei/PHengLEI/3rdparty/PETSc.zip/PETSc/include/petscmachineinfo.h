static const char *petscmachineinfo = "\n"
"-----------------------------------------\n"
"Libraries compiled on 2023-04-26 04:02:26 on master \n"
"Machine characteristics: Linux-3.10.0-1160.76.1.el7.x86_64-x86_64-with-centos-7.5.1804-Core\n"
"Using PETSc directory: /home/wbq/PHengLEI_Project/Softwares/petsc-3.18.3-opt\n"
"Using PETSc arch: \n"
"-----------------------------------------\n";
static const char *petsccompilerinfo = "\n"
"Using C compiler: mpicc -fPIE -fPIC -O3   \n"
"-----------------------------------------\n";
static const char *petsccompilerflagsinfo = "\n"
"Using include paths: -I/home/wbq/PHengLEI_Project/Softwares/petsc-3.18.3-opt/include\n"
"-----------------------------------------\n";
static const char *petsclinkerinfo = "\n"
"Using C linker: mpicc\n"
"Using libraries: -Wl,-rpath,/home/wbq/PHengLEI_Project/Softwares/petsc-3.18.3-opt/lib -L/home/wbq/PHengLEI_Project/Softwares/petsc-3.18.3-opt/lib -lpetsc -Wl,-rpath,/home/wbq/PHengLEI_Project/Softwares/petsc-3.18.3-opt/lib -L/home/wbq/PHengLEI_Project/Softwares/petsc-3.18.3-opt/lib -lf2clapack -lf2cblas -lpthread -lm -lquadmath -lstdc++ -ldl\n"
"-----------------------------------------\n";
