#if defined(_WIN32) || defined(WIN32)
#include "mydrand48.h"
static unsigned long long seed = 1;

double drand48( )
{
    seed = (aaa * seed + ccc) & 0xFFFFFFFFFFFFLL;
    //unsigned int x = seed >> 16;
    //return 	((double)x / (double)mmm);
    return (double) (seed >> 16) / (double) (mmm);
}

void srand48(unsigned int i)
{
    seed  = (((long long int)i) << 16) | rand();
}

#endif