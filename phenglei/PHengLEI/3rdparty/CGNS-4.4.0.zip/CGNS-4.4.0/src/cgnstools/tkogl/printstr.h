int PrintString(Tcl_Interp *interp, int argc, char* argv []);
int LoadBitmapFont(Tcl_Interp *interp, int argc, char* argv []);


