int glPhoto _ANSI_ARGS_((Tcl_Interp *interp, int argc, char* argv []));


